<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2016/10/11
 * Time: 13:48
 */

namespace common\models;


class WxUser
{

}