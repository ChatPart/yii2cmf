<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * CubridDsn
 *
 */
class CubridDsn extends Dsn
{

    /**
     * defaultPort
     *
     * @var int 3306
     */
    protected $defaultPort = 3306;
}