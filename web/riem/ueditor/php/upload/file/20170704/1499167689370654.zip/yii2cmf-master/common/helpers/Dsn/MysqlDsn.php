<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * MysqlDsn
 *
 */
class MysqlDsn extends Dsn
{

    protected $defaultPort = '3306';

}