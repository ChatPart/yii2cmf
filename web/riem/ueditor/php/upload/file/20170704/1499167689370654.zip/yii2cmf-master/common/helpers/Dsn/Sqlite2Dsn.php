<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * Sqlite2Dsn
 *
 */
class Sqlite2Dsn extends Dsn
{

}