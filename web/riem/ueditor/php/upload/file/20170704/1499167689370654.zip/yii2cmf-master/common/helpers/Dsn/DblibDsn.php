<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * DblibDsn
 *
 */
class DblibDsn extends Dsn
{

}