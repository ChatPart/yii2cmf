<?php
/**
 * Created by PhpStorm.
 * User: yidashi
 * Date: 16/7/26
 * Time: 下午3:32
 */

namespace common\modules\city;

class Module extends \yii\base\Module
{
    public function init()
    {
        parent::init();
    }
}