<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * MysqliDsn
 *
 */
class MysqliDsn extends Dsn
{

}