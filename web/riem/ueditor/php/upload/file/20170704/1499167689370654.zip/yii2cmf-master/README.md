## 安装:

进入项目根目录

1. `composer install`

2. 直接访问项目地址即可！


## demo

前台地址 `www.51siyuan.cn`

后台地址: `www.51siyuan.cn/admin`  帐号 `demo` 密码 `111111`

## doc

[更多文档](http://www.51siyuan.cn/book/2)


